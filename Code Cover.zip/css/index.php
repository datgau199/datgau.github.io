<script>
window.location.replace("/");
</script>